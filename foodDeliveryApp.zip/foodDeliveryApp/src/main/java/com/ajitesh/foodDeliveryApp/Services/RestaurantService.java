package com.ajitesh.foodDeliveryApp.Services;

import com.ajitesh.foodDeliveryApp.Exceptions.foodItemAlreadyExistsException;
import com.ajitesh.foodDeliveryApp.Model.FoodItem;
import com.ajitesh.foodDeliveryApp.Model.Restaurant;
import com.ajitesh.foodDeliveryApp.Model.User;
import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sun.text.resources.da.FormatData_da;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class RestaurantService {

    HashMap<Integer , Restaurant> restaurantsMap = new HashMap<>();
    HashMap<Integer , List<FoodItem>> foodItemsMapList = new HashMap<>();

    @Autowired
    private SearchServiceImpl searchServiceImpl;

    public List<Restaurant> searchRestaurantByName(String restaurantName){
       return searchServiceImpl.searchRestaurantByName(restaurantName , restaurantsMap);
    }

    public List<Restaurant> searchRestaurantByCity(String city) {
        return searchServiceImpl.searchRestaurantByCity(city , restaurantsMap);
    }


    public void addFoodItem(@NonNull Restaurant restaurant ,
                            @NonNull FoodItem foodItem) {

        List<FoodItem> foodItemList = new ArrayList<>();
        foodItemList = foodItemsMapList.get(restaurant.getRestaurantId());
        for(FoodItem foodItemInList : foodItemList){
            if(foodItemInList.getFoodItemId().equals(foodItem.getFoodItemId())){
                throw new foodItemAlreadyExistsException();
            }
        }
        foodItemList.add(foodItem);
        foodItemsMapList.put(restaurant.getRestaurantId() , foodItemList);

    }

    public void updateFoodItem(@NonNull Restaurant restaurant ,
                               @NonNull  FoodItem foodItem) {
        List<FoodItem> foodItemList = new ArrayList<>();
        foodItemList = foodItemsMapList.get(restaurant.getRestaurantId());
        for(FoodItem foodItemInList : foodItemList) {
            if (foodItemInList.getFoodItemId().equals(foodItem.getFoodItemId())) {
                foodItemList.add(foodItem);
            }
            else{
                foodItemList.add(foodItemInList);
            }
        }
        foodItemsMapList.put(restaurant.getRestaurantId() , foodItemList);
    }
}

