package com.ajitesh.foodDeliveryApp.Exceptions;

public class UserDoNotExistsException extends RuntimeException {
}
