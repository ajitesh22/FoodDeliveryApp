package com.ajitesh.foodDeliveryApp.Model;

import lombok.Data;

@Data
public class Payment {

    String orderId;
    Double orderAmount;
    PaymentMode paymentMode;
    PaymentStatus paymentStatus;
}
