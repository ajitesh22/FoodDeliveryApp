package com.ajitesh.foodDeliveryApp.Model;

import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

@Data
@Builder
public class Location {

    String street;
    String city;
    String state;
    String pinCode;
}
