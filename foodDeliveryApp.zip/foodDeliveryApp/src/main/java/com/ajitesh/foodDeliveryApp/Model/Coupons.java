package com.ajitesh.foodDeliveryApp.Model;

public enum Coupons {
    NEWUSER,
    DISCOUNT50
}
