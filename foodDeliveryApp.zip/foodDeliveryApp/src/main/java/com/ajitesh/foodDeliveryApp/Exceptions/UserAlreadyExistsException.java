package com.ajitesh.foodDeliveryApp.Exceptions;

public class UserAlreadyExistsException extends RuntimeException {

}
