package com.ajitesh.foodDeliveryApp.Model;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class Order {
    String orderId;
    String restaurantId;
    Double orderPrice;
    String OrderDescription;
    Date timeOfOrder;
    OrderStatus orderStatus;
    List<FoodItem> foodItemsOrdered;

}
