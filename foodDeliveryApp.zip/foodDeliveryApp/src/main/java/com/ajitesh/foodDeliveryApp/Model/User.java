package com.ajitesh.foodDeliveryApp.Model;

import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

import java.util.List;

@Data
@Builder
public class User {
    @NonNull
    String name;
    @NonNull
    Integer userId;
    @NonNull
    Integer phoneNumber;
    @NonNull
    String email;
    Location location;
    List<Integer> orderHistory;
}
