package com.ajitesh.foodDeliveryApp.Model;

public enum OrderStatus {
    DELIVERED,
    OUT_FOR_DELIVERY,
    SUCCESS,
    CANCELLED
}
