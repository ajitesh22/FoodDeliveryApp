package com.ajitesh.foodDeliveryApp.Model;

import lombok.Data;

@Data
public class Review {
    Integer reviewId;
    Integer userId;
    Integer restaurantId;
    String review;
    Double rating;

}
