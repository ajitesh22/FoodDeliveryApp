package com.ajitesh.foodDeliveryApp.Model;

public enum PaymentMode {
    CREDIT_CARD,
    DEBIT_CARD,
    PAYPAL,
    WALLET,
    COD
}
