package com.ajitesh.foodDeliveryApp.Model;

import javafx.util.Pair;
import lombok.Data;

import java.util.HashMap;
import java.util.List;

@Data
public class Cart {

    Integer userId;
    Integer restaurantId;
    HashMap<Integer , Integer> foodItemsAddedInCart;
}

/*
*  user ----> open app -> create profile / update profile / delete profile
*  user ----> search for restaurant by name or city
*  user ----> add food items to the cart from the selected restaurant
*  user ----> checkout/ place order once payment is successful
*  for successful order delivery agent is assigned
* other features
* user can view history of orders placed
* delivery agent can also view history of all orders delivered
*
*
*
* */
