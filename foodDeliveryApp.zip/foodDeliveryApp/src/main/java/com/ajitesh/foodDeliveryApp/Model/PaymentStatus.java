package com.ajitesh.foodDeliveryApp.Model;

public enum PaymentStatus {
    PAID,
    PENDING,
    DECLINED
}
