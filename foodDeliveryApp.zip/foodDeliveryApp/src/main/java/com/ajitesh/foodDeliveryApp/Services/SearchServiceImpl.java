package com.ajitesh.foodDeliveryApp.Services;

import com.ajitesh.foodDeliveryApp.Model.Restaurant;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SearchServiceImpl implements SearchService {

    @Override
    public List<Restaurant> searchRestaurantByName(String restaurantName , HashMap<Integer , Restaurant> restaurantsMap) {

        List<Restaurant> matchedRestaurantsList = restaurantsMap.entrySet()
                .stream()
                .filter( e-> e.getValue().getName().equalsIgnoreCase(restaurantName))
                .map(Map.Entry::getValue)
                .collect(Collectors.toList());
        return matchedRestaurantsList;
    }

    @Override
    public List<Restaurant> searchRestaurantByCity(String city , HashMap<Integer , Restaurant> restaurantsMap) {


        List<Restaurant> matchedRestaurantsList = restaurantsMap.entrySet()
                .stream()
                .filter( e-> e.getValue().getLocation().getCity().equalsIgnoreCase(city))
                .map(Map.Entry::getValue)
                .collect(Collectors.toList());
        return matchedRestaurantsList;
    }
}
