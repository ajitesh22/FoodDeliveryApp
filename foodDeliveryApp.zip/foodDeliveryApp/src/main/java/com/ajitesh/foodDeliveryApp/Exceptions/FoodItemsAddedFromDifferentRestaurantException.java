package com.ajitesh.foodDeliveryApp.Exceptions;

public class FoodItemsAddedFromDifferentRestaurantException extends RuntimeException {
}
