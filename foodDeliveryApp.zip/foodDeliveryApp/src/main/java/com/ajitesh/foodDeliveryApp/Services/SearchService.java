package com.ajitesh.foodDeliveryApp.Services;

import com.ajitesh.foodDeliveryApp.Model.Restaurant;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

@Service
public interface SearchService {
    public List<Restaurant> searchRestaurantByName(String name , HashMap<Integer , Restaurant> restaurantsMap);
    public List<Restaurant> searchRestaurantByCity(String city , HashMap<Integer , Restaurant> restaurantsMap);
}
