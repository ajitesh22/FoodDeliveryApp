package com.ajitesh.foodDeliveryApp.Model;


import lombok.Data;

import java.util.List;

@Data
public class Restaurant {

    String name;
    Integer restaurantId;
    Location location;
    Double overallRating;
    List<Review> reviews;
}
