package com.ajitesh.foodDeliveryApp.Controller;


import com.ajitesh.foodDeliveryApp.Model.Restaurant;
import com.ajitesh.foodDeliveryApp.Model.User;
import com.ajitesh.foodDeliveryApp.Services.RestaurantService;
import com.ajitesh.foodDeliveryApp.Services.SearchService;
import com.ajitesh.foodDeliveryApp.Services.UserService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private RestaurantService restaurantService;

    public final Logger LOGGER  =
            LoggerFactory.getLogger(UserController.class);

    UserController(UserService userService , RestaurantService restaurantService){
        this.userService = userService;
        this.restaurantService = restaurantService;
    }

    @PostMapping("/createUserProfile")
    public ResponseEntity<String> createUserProfile(@Valid @RequestBody User user){
        userService.createUserProfile(user);
        return ResponseEntity.ok("");
    }

    @PostMapping("/updateUserProfile")
    public ResponseEntity<String> updateUserProfile(@Valid @RequestBody User user){
        userService.updateUserProfile(user);
        return ResponseEntity.ok("");
    }


    @DeleteMapping("/deleteUserProfile")
    public ResponseEntity<String> deleteUserProfile(@Valid @RequestBody Integer userId){
        userService.deleteUserProfile(userId);
        return ResponseEntity.ok("");
    }

    // user should be able to search by city and restaurantName

    @GetMapping("/searchRestaurantByName")
    public List<Restaurant> searchRestaurantByName(@Valid @RequestBody String restaurantName){
        return restaurantService.searchRestaurantByName(restaurantName);
    }

    @GetMapping("/searchRestaurantByCity")
    public List<Restaurant> searchRestaurantByCity(@Valid @RequestBody String city){
        return restaurantService.searchRestaurantByCity(city);
    }

}
