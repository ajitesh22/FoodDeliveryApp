package com.ajitesh.foodDeliveryApp.Services;

import com.ajitesh.foodDeliveryApp.Exceptions.FoodItemsAddedFromDifferentRestaurantException;
import com.ajitesh.foodDeliveryApp.Model.Cart;
import com.ajitesh.foodDeliveryApp.Model.FoodItem;
import com.ajitesh.foodDeliveryApp.Model.Restaurant;
import com.ajitesh.foodDeliveryApp.Model.User;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    HashMap<Integer,Cart> userCartMap = new HashMap<>();

    @Override
    public void addFoodItemInCart(Restaurant restaurant, User user, FoodItem foodItem, Integer quantity) {
        Cart userCart =  userCartMap.get(user.getUserId());
        if(userCart.getRestaurantId()!=null && !userCart.getRestaurantId().equals(restaurant.getRestaurantId())){
            throw new FoodItemsAddedFromDifferentRestaurantException();
        }
        HashMap<Integer , Integer> foodItemList = userCart.getFoodItemsAddedInCart();
        foodItemList.put(foodItem.getFoodItemId() , quantity);
        userCart.setRestaurantId(restaurant.getRestaurantId());
        userCart.setFoodItemsAddedInCart(foodItemList);
        userCartMap.put(user.getUserId() , userCart);
    }

    @Override
    public void removeFoodItemFromCart(Restaurant restaurant, User user, FoodItem foodItem, Integer quantity) {
        Cart userCart =  userCartMap.get(user.getUserId());
        if(userCart.getRestaurantId()!=null && !userCart.getRestaurantId().equals(restaurant.getRestaurantId())){
            throw new FoodItemsAddedFromDifferentRestaurantException();
        }

    }
}
