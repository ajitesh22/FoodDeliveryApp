package com.ajitesh.foodDeliveryApp.Exceptions;

public class foodItemAlreadyExistsException extends RuntimeException {
}
