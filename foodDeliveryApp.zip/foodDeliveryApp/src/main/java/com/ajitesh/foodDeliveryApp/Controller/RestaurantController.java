package com.ajitesh.foodDeliveryApp.Controller;

import com.ajitesh.foodDeliveryApp.Model.FoodItem;
import com.ajitesh.foodDeliveryApp.Model.Restaurant;
import com.ajitesh.foodDeliveryApp.Model.User;
import com.ajitesh.foodDeliveryApp.Services.RestaurantService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;

public class RestaurantController {

    private RestaurantService restaurantService;

    @PostMapping("/addFoodItem")
    public ResponseEntity<String> addFoodItem(@Valid @RequestBody Restaurant restaurant,
                                              @Valid @RequestBody FoodItem foodItem){
        restaurantService.addFoodItem(restaurant , foodItem);
        return ResponseEntity.ok("");
    }

    @PostMapping("/updateFoodItem")
    public ResponseEntity<String> updateFoodItem(@Valid @RequestBody Restaurant restaurant,
                                                 @Valid @RequestBody FoodItem foodItem){
        restaurantService.updateFoodItem(restaurant , foodItem);
        return ResponseEntity.ok("");
    }

}
