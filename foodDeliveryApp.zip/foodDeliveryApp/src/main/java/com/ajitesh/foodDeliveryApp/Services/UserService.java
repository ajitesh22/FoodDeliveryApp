package com.ajitesh.foodDeliveryApp.Services;

import com.ajitesh.foodDeliveryApp.Exceptions.UserAlreadyExistsException;
import com.ajitesh.foodDeliveryApp.Exceptions.UserDoNotExistsException;
import com.ajitesh.foodDeliveryApp.Model.User;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.HashMap;

@Service
public class UserService {

    HashMap<Integer , User> usersProfile = new HashMap<>();

    public HashMap<Integer, User> getUsersProfile() {
        return usersProfile;
    }

    public void setUsersProfile(HashMap<Integer, User> usersProfile) {
        this.usersProfile = usersProfile;
    }
    //create , update , delete profile

    public void createUserProfile(@NotNull final User user) {

        if(usersProfile.containsKey(user.getUserId())){
            throw new UserAlreadyExistsException();
        }
        usersProfile.put(user.getUserId() , user);
    }

    public void updateUserProfile(@NotNull final User user){

        if(!usersProfile.containsKey(user.getUserId())){
            throw new UserDoNotExistsException();
        }
        usersProfile.put(user.getUserId() , user);
    }

    public void deleteUserProfile(@NotNull final Integer userId){
        if(!usersProfile.containsKey(userId)){
            throw new UserDoNotExistsException();
        }
        usersProfile.remove(userId);
    }

}
