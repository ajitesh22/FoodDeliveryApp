package com.ajitesh.foodDeliveryApp.Services;

import com.ajitesh.foodDeliveryApp.Model.FoodItem;
import com.ajitesh.foodDeliveryApp.Model.Restaurant;
import com.ajitesh.foodDeliveryApp.Model.User;
import org.springframework.stereotype.Service;

@Service
public interface CartService {

    public void addFoodItemInCart(Restaurant restaurant , User user , FoodItem foodItem , Integer quantity);
    public void removeFoodItemFromCart(Restaurant restaurant , User user , FoodItem foodItem , Integer quantity);
}
