package com.ajitesh.foodDeliveryApp.Model;

import lombok.Data;

@Data
public class FoodItem {
    Integer foodItemId;
    Double rating;
    String foodDetails;
    Integer quantity;
    Double price;
}
