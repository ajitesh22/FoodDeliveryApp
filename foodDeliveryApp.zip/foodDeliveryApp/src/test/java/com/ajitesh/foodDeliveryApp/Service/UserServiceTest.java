package com.ajitesh.foodDeliveryApp.Service;



import com.ajitesh.foodDeliveryApp.Model.Location;
import com.ajitesh.foodDeliveryApp.Model.User;
import com.ajitesh.foodDeliveryApp.Services.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest
public class UserServiceTest {

    @Autowired
    private UserService userService;



    @BeforeEach
    void setup() {
        Location location = Location.builder()
                                    .city("JAMSHEDPUR")
                                    .pinCode("831017")
                                    .street("SHAKTINAGAR")
                                    .state("JHARKHAND")
                                    .build();
        User user = User.builder()
                        .name("AJITESH")
                        .email("ajiteshkmr802@gmail.com")
                        .phoneNumber(563444)
                        .userId(23144)
                        .build();

        userService.createUserProfile(user);
    }

    @Test
    @DisplayName("")
    public void whenUserCreated_UserShouldBeFoundInMap(){
        User found = userService.getUsersProfile().get(23144);
        assertEquals(found.getUserId() , 23544);

    }
}
