package com.ajitesh.foodDeliveryApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDeliveryAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
